import React from 'react';
import { useGameState } from './hooks/useGameState';
import { MenuScreen } from './components/MenuScreen';
import { GameScreen } from './components/GameScreen';
import { LoadGameScreen } from './components/LoadGameScreen';
import { CharacterScreen } from './components/CharacterScreen';

function App() {
  const {
    currentScreen,
    setCurrentScreen,
    games,
    messages,
    userInput,
    setUserInput,
    isLoading,
    error,
    startNewGame,
    loadGames,
    loadGame,
    deleteGame,
    startEditCharacter,
    sendMessage
  } = useGameState();

  const handleShowLoadGame = async () => {
    await loadGames();
    setCurrentScreen('load');
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(userInput);
  };

  switch (currentScreen) {
    case 'menu':
      return (
        <MenuScreen
          onNewGame={startNewGame}
          onLoadGame={handleShowLoadGame}
          isLoading={isLoading}
          error={error}
        />
      );

    case 'load':
      return (
        <LoadGameScreen
          games={games}
          isLoading={isLoading}
          error={error}
          onLoadGame={loadGame}
          onDeleteGame={deleteGame}
          onEditGame={startEditCharacter}
          onBack={() => setCurrentScreen('menu')}
        />
      );

    case 'create-character':
      return (
        <CharacterScreen
          title="Creación de Personaje"
          messages={messages}
          userInput={userInput}
          isLoading={isLoading}
          onInputChange={setUserInput}
          onSendMessage={handleSendMessage}
          onBack={() => setCurrentScreen('menu')}
        />
      );

    case 'edit-character':
      return (
        <CharacterScreen
          title="Edición de Personaje"
          messages={messages}
          userInput={userInput}
          isLoading={isLoading}
          onInputChange={setUserInput}
          onSendMessage={handleSendMessage}
          onBack={() => setCurrentScreen('menu')}
        />
      );

    default:
      return (
        <GameScreen
          messages={messages}
          userInput={userInput}
          isLoading={isLoading}
          onInputChange={setUserInput}
          onSendMessage={handleSendMessage}
          onMenuClick={() => setCurrentScreen('menu')}
        />
      );
  }
}

export default App;
// Tipos comunes utilizados en la aplicación
export interface GameMessage {
  id: number;
  text: string;
  type: 'narrative' | 'combat' | 'dialog' | 'system';
  timestamp: string;
}

export interface GameInfo {
  game_id: string;
  id_personaje: number;
  descripcion: string;
  fecha_creacion: string;
}

// Tipos de pantallas disponibles en la aplicación
export type Screen = 'menu' | 'game' | 'load' | 'create-character' | 'edit-character';

// Tipos de respuesta del servidor
export interface ServerResponse {
  response: string;
  type: string;
  game_id?: string;
  id_personaje?: number;
}

// Configuración de los webhooks
export const WEBHOOKS = {
  MAIN: 'https://n8n-hackathon.onrender.com/webhook/main-controller',
  NARRATIVE: 'https://n8n-hackathon.onrender.com/webhook/narrative-controller',
  CHARACTER: 'https://n8n-hackathon.onrender.com/webhook/charracter_controller',
  EDIT: 'https://n8n-hackathon.onrender.com/webhook/edit_char_controller'
} as const;
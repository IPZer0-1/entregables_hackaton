import React from 'react';

interface MenuScreenProps {
  onNewGame: () => void;
  onLoadGame: () => void;
  isLoading?: boolean;
  error?: string;
}

// Componente para la pantalla del menú principal
export const MenuScreen: React.FC<MenuScreenProps> = ({
  onNewGame,
  onLoadGame,
  isLoading,
  error
}) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <div className="text-center">
        <h1 className="retro-font text-4xl text-amber-500 mb-12">RPG Game Master</h1>
        {error && (
          <div className="mb-6 p-4 bg-red-100 text-red-700 rounded-lg">
            {error}
          </div>
        )}
        <div className="space-y-6">
          <button 
            onClick={onNewGame} 
            disabled={isLoading}
            className={`retro-button w-64 block mx-auto mb-4 ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isLoading ? 'Cargando...' : 'Nueva Partida'}
          </button>
          <button 
            onClick={onLoadGame}
            disabled={isLoading} 
            className={`retro-button w-64 block mx-auto ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            Continuar Partida
          </button>
        </div>
      </div>
    </div>
  );
};
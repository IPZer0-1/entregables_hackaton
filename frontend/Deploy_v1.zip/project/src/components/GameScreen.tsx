import React from 'react';
import { ScrollText, Settings, User } from 'lucide-react';
import { MessageList } from './MessageList';
import { GameMessage } from '../types';

interface GameScreenProps {
  messages: GameMessage[];
  userInput: string;
  isLoading: boolean;
  onInputChange: (value: string) => void;
  onSendMessage: (e: React.FormEvent) => void;
  onMenuClick: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  messages,
  userInput,
  isLoading,
  onInputChange,
  onSendMessage,
  onMenuClick
}) => {
  return (
    <div className="min-h-screen p-4">
      <div className="container mx-auto flex flex-col h-screen medieval-container rounded-lg">
        <header className="medieval-header flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <ScrollText className="w-8 h-8 text-[var(--gold)]" />
            <h1 className="retro-font text-2xl text-[var(--gold)]">RPG Game Master</h1>
          </div>
          <div className="flex space-x-4">
            <button onClick={onMenuClick} className="retro-button">
              Menú Principal
            </button>
            <button className="p-2 hover:bg-[var(--wood)] rounded-full transition-colors">
              <Settings className="w-6 h-6 text-[var(--gold)]" />
            </button>
            <button className="p-2 hover:bg-[var(--wood)] rounded-full transition-colors">
              <User className="w-6 h-6 text-[var(--gold)]" />
            </button>
          </div>
        </header>

        <div className="flex-1 p-6">
          <MessageList 
            messages={messages}
            userInput={userInput}
            isLoading={isLoading}
            onInputChange={onInputChange}
            onSendMessage={onSendMessage}
          />
        </div>
      </div>
    </div>
  );
};
import React from 'react';
import { Trash2, Edit, TowerControl as GameController } from 'lucide-react';
import { GameInfo } from '../types';

interface LoadGameScreenProps {
  games: GameInfo[];
  isLoading: boolean;
  error: string | null;
  onLoadGame: (gameId: string, characterId: number) => void;
  onDeleteGame: (gameId: string, characterId: number) => void;
  onEditGame: (gameId: string, characterId: number) => void;
  onBack: () => void;
}

export const LoadGameScreen: React.FC<LoadGameScreenProps> = ({
  games,
  isLoading,
  error,
  onLoadGame,
  onDeleteGame,
  onEditGame,
  onBack
}) => {
  const [deleteConfirm, setDeleteConfirm] = React.useState<string | null>(null);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleDelete = (gameId: string, characterId: number) => {
    if (deleteConfirm === gameId) {
      onDeleteGame(gameId, characterId);
      setDeleteConfirm(null);
    } else {
      setDeleteConfirm(gameId);
    }
  };

  const handleCancelDelete = () => {
    setDeleteConfirm(null);
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-500 mx-auto mb-4"></div>
          <p className="retro-font text-white">Cargando partidas...</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="text-center py-8">
          <div className="bg-red-100 text-red-800 p-4 rounded-lg mb-4">
            <p className="retro-font">{error}</p>
          </div>
          <button onClick={onBack} className="retro-button">
            Volver al Menú Principal
          </button>
        </div>
      );
    }

    if (games.length === 0) {
      return (
        <div className="text-center py-8">
          <GameController className="w-16 h-16 text-amber-500 mx-auto mb-4" />
          <h3 className="retro-font text-amber-500 text-xl mb-4">No hay partidas guardadas</h3>
          <p className="retro-font text-gray-400 mb-6">
            ¡Comienza una nueva aventura desde el menú principal!
          </p>
          <button onClick={onBack} className="retro-button">
            Volver al Menú Principal
          </button>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {games.map((game) => (
          <div
            key={game.game_id}
            className="bg-slate-700 p-6 rounded-lg hover:bg-slate-600 transition-colors relative"
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="retro-font text-amber-500 text-lg">{game.descripcion}</h3>
                <div className="text-xs text-gray-400 mt-1 space-x-2">
                  <span className="inline-block">Personaje #{game.id_personaje}</span>
                  <span className="inline-block">•</span>
                  <span className="inline-block">Creada el: {formatDate(game.fecha_creacion)}</span>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => onEditGame(game.game_id, game.id_personaje)}
                  className="p-2 hover:bg-slate-500 rounded transition-colors"
                  title="Editar personaje"
                >
                  <Edit className="w-4 h-4 text-blue-400" />
                </button>
                <button
                  onClick={() => handleDelete(game.game_id, game.id_personaje)}
                  className="p-2 hover:bg-slate-500 rounded transition-colors"
                  title={deleteConfirm === game.game_id ? "¿Confirmar borrado?" : "Borrar partida"}
                >
                  <Trash2 className={`w-4 h-4 ${deleteConfirm === game.game_id ? 'text-red-500' : 'text-red-400'}`} />
                </button>
              </div>
            </div>

            <button
              onClick={() => onLoadGame(game.game_id, game.id_personaje)}
              className="retro-button text-sm w-full mt-4"
            >
              Cargar Partida
            </button>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <div className="bg-slate-800 p-8 rounded-lg shadow-lg max-w-2xl w-full relative">
        <h2 className="retro-font text-2xl text-amber-500 mb-6">Partidas Guardadas</h2>
        
        {renderContent()}
        
        {games.length > 0 && (
          <button
            onClick={onBack}
            className="retro-button mt-6"
          >
            Volver
          </button>
        )}

        {/* Modal de confirmación */}
        {deleteConfirm && (
          <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
            <div className="bg-slate-800 p-6 rounded-lg shadow-xl text-center max-w-md mx-4">
              <p className="retro-font text-white mb-4">
                ¿Estás seguro de que quieres borrar esta partida?
              </p>
              <div className="flex space-x-4 justify-center">
                <button
                  onClick={() => {
                    const game = games.find(g => g.game_id === deleteConfirm);
                    if (game) {
                      handleDelete(game.game_id, game.id_personaje);
                    }
                  }}
                  className="retro-button bg-red-500 hover:bg-red-600"
                >
                  Confirmar
                </button>
                <button
                  onClick={handleCancelDelete}
                  className="retro-button"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
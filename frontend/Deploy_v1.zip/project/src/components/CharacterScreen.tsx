import React from 'react';
import { ScrollText } from 'lucide-react';
import { GameMessage } from '../types';
import { MessageList } from './MessageList';

interface CharacterScreenProps {
  title: string;
  messages: GameMessage[];
  userInput: string;
  isLoading: boolean;
  onInputChange: (value: string) => void;
  onSendMessage: (e: React.FormEvent) => void;
  onBack?: () => void;
}

export const CharacterScreen: React.FC<CharacterScreenProps> = ({
  title,
  messages,
  userInput,
  isLoading,
  onInputChange,
  onSendMessage,
  onBack
}) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <div className="container mx-auto px-4 py-8 flex flex-col h-screen">
        <header className="flex items-center justify-between mb-6 bg-slate-800 p-4 rounded-lg shadow-lg">
          <div className="flex items-center space-x-2">
            <ScrollText className="w-8 h-8 text-amber-500" />
            <h1 className="retro-font text-2xl">{title}</h1>
          </div>
          {onBack && (
            <button onClick={onBack} className="retro-button">
              Volver
            </button>
          )}
        </header>

        <div className="flex-1">
          <div className="bg-slate-800 rounded-lg shadow-lg p-6 h-full">
            <MessageList
              messages={messages}
              userInput={userInput}
              isLoading={isLoading}
              onInputChange={onInputChange}
              onSendMessage={onSendMessage}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
import React, { useEffect, useRef } from 'react';
import { Sword, MessageCircle, Scroll } from 'lucide-react';
import { GameMessage } from '../types';

interface MessageListProps {
  messages: GameMessage[];
  userInput: string;
  isLoading: boolean;
  onInputChange: (value: string) => void;
  onSendMessage: (e: React.FormEvent) => void;
}

export const MessageList: React.FC<MessageListProps> = ({
  messages,
  userInput,
  isLoading,
  onInputChange,
  onSendMessage
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isLoading && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isLoading, messages]);

  useEffect(() => {
    if (messages.length > 0 && messagesContainerRef.current) {
      const container = messagesContainerRef.current;
      container.scrollTop = container.scrollHeight;
    }
  }, [messages]);

  const getMessageIcon = (type: string) => {
    switch (type) {
      case 'combat': return <Sword className="w-5 h-5 text-red-800" />;
      case 'dialog': return <MessageCircle className="w-5 h-5 text-green-800" />;
      case 'narrative': return <Scroll className="w-5 h-5 text-blue-800" />;
      default: return null;
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 flex flex-col justify-end">
        <div 
          ref={messagesContainerRef}
          className="overflow-y-auto space-y-4 pr-2 scroll-container"
          style={{ maxHeight: 'calc(100vh - 250px)' }}
        >
          {messages.map(message => (
            <div
              key={message.id}
              className={`message-box ${message.type}`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2">
                  {getMessageIcon(message.type)}
                </div>
                <span className="text-xs opacity-50 flex-shrink-0 ml-2 retro-font">{message.timestamp}</span>
              </div>
              <p className="retro-font text-sm whitespace-pre-wrap break-words">{message.text}</p>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      <form onSubmit={onSendMessage} className="mt-4 sticky bottom-0 bg-transparent pt-4">
        <div className="flex space-x-2">
          <input
            ref={inputRef}
            type="text"
            value={userInput}
            onChange={(e) => onInputChange(e.target.value)}
            disabled={isLoading}
            className="medieval-input flex-1"
            placeholder={isLoading ? "Esperando respuesta..." : "¿Qué deseas hacer?"}
          />
          <button
            type="submit"
            disabled={isLoading}
            className="retro-button whitespace-nowrap"
          >
            {isLoading ? "Enviando..." : "Enviar"}
          </button>
        </div>
      </form>
    </div>
  );
};
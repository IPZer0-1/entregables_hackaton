import { WEBHOOKS, ServerResponse, GameInfo } from '../types';

const handleApiCall = async (url: string, data: any): Promise<any> => {
  try {
    console.log(`Llamando a ${url} con datos:`, data);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`Error del servidor: ${response.status}`);
    }

    const responseText = await response.text();
    console.log('Respuesta del servidor:', responseText);

    if (!responseText.trim()) {
      return []; // Retornamos un array vacío cuando no hay respuesta
    }

    try {
      const jsonResponse = JSON.parse(responseText);
      return jsonResponse;
    } catch (parseError) {
      if (responseText.trim()) {
        return {
          response: responseText.trim(),
          type: 'narrative'
        };
      }
      return []; // Retornamos un array vacío si hay error al parsear
    }
  } catch (error) {
    console.error('Error en la llamada a la API:', error);
    throw error;
  }
};

const handleGameResponse = (response: any): ServerResponse => {
  console.log('Procesando respuesta:', response);

  if (Array.isArray(response) && response.length > 0) {
    response = response[0];
  }

  if (typeof response === 'string') {
    return {
      response: response.trim(),
      type: 'narrative'
    };
  }

  if (response && typeof response === 'object') {
    if (typeof response.response === 'string') {
      return {
        response: response.response.trim(),
        type: response.type || 'narrative',
        game_id: response.game_id,
        id_personaje: response.id_personaje ? Number(response.id_personaje) : undefined
      };
    }

    if (Object.keys(response).length > 0) {
      const firstKey = Object.keys(response)[0];
      const possibleResponse = response[firstKey];
      
      if (typeof possibleResponse === 'string') {
        return {
          response: possibleResponse.trim(),
          type: 'narrative'
        };
      }
    }
  }

  throw new Error('Formato de respuesta no válido');
};

const parseCharacterId = (value: any): number => {
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (!isNaN(parsed)) return parsed;
  }
  console.warn('ID de personaje inválido:', value);
  return 0;
};

export const fetchGameList = async (): Promise<GameInfo[]> => {
  const response = await handleApiCall(WEBHOOKS.MAIN, { action: 'game_list' });
  
  if (!response) return [];
  
  if (Array.isArray(response)) {
    if (response.length === 0) return [];
    return response.map(game => ({
      ...game,
      id_personaje: parseCharacterId(game.id_personaje)
    }));
  }
  
  if (response && typeof response === 'object' && Object.keys(response).length > 0) {
    return [{
      ...response,
      id_personaje: parseCharacterId(response.id_personaje)
    }];
  }
  
  return []; // Retornamos un array vacío si no hay partidas
};

export const sendGameAction = async (
  message: string,
  gameId: string,
  characterId: number
): Promise<ServerResponse> => {
  const response = await handleApiCall(WEBHOOKS.NARRATIVE, {
    action: 'game_action',
    game_id: gameId,
    id_personaje: characterId,
    message
  });
  return handleGameResponse(response);
};

export const sendCharacterAction = async (
  message: string,
  chatId: string
): Promise<ServerResponse> => {
  const response = await handleApiCall(WEBHOOKS.CHARACTER, {
    action: 'char_action',
    chat_id: chatId,
    message
  });
  return handleGameResponse(response);
};

export const startCharacterEdit = async (
  gameId: string,
  characterId: number,
  chatId: string
): Promise<ServerResponse> => {
  const response = await handleApiCall(WEBHOOKS.EDIT, {
    action: 'start_edit',
    game_id: gameId,
    id_personaje: characterId,
    chat_id: chatId
  });
  return handleGameResponse(response);
};

export const sendEditAction = async (
  message: string,
  gameId: string,
  characterId: number,
  chatId: string
): Promise<ServerResponse> => {
  const response = await handleApiCall(WEBHOOKS.EDIT, {
    action: 'edit_action',
    game_id: gameId,
    id_personaje: characterId,
    chat_id: chatId,
    message
  });
  return handleGameResponse(response);
};

export const deleteGame = async (
  gameId: string,
  characterId: number
): Promise<void> => {
  await handleApiCall(WEBHOOKS.MAIN, {
    action: 'delete_game',
    game_id: gameId,
    id_personaje: characterId
  });
};
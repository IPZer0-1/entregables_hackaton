import { useState, useCallback, useRef } from 'react';
import { GameMessage, GameInfo, Screen, ServerResponse } from '../types';
import * as gameApi from '../services/gameApi';

export const useGameState = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('menu');
  const [games, setGames] = useState<GameInfo[]>([]);
  const [messages, setMessages] = useState<GameMessage[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentGameId, setCurrentGameId] = useState<string>('');
  const [currentCharacterId, setCurrentCharacterId] = useState<number>(0);
  const [error, setError] = useState<string>('');
  const chatIdRef = useRef<string>('');

  const generateChatId = () => {
    const now = new Date();
    return `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}`;
  };

  const clearGameState = () => {
    setCurrentGameId('');
    setCurrentCharacterId(0);
    setMessages([]);
    chatIdRef.current = '';
  };

  const addMessage = useCallback((text: string, type: GameMessage['type']) => {
    setMessages(prev => [...prev, {
      id: Date.now(),
      text,
      type,
      timestamp: new Date().toLocaleTimeString()
    }]);
  }, []);

  const handleServerResponse = useCallback(async (response: ServerResponse) => {
    if (response.response === 'char_end' && response.type === 'system') {
      if (response.game_id) setCurrentGameId(response.game_id);
      if (response.id_personaje) setCurrentCharacterId(response.id_personaje);
      addMessage('¡Personaje actualizado! Volviendo a la lista de partidas...', 'system');
      await loadGames();
      setCurrentScreen('load');
      chatIdRef.current = '';
    } else {
      addMessage(response.response, response.type as GameMessage['type']);
    }
  }, [addMessage]);

  const startNewGame = () => {
    clearGameState();
    chatIdRef.current = generateChatId();
    setCurrentScreen('create-character');
  };

  const loadGames = async () => {
    try {
      setIsLoading(true);
      setError('');
      const gamesData = await gameApi.fetchGameList();
      console.log('Juegos cargados:', gamesData);
      setGames(gamesData);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error al cargar las partidas');
      setGames([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadGame = async (gameId: string, characterId: number) => {
    try {
      console.log('Cargando juego:', { gameId, characterId });
      setIsLoading(true);
      setError('');
      setCurrentGameId(gameId);
      setCurrentCharacterId(characterId);
      setMessages([{
        id: Date.now(),
        text: "Continuando tu aventura...",
        type: 'narrative',
        timestamp: new Date().toLocaleTimeString()
      }]);
      setCurrentScreen('game');
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error al cargar la partida');
    } finally {
      setIsLoading(false);
    }
  };

  const deleteGame = async (gameId: string, characterId: number) => {
    try {
      setIsLoading(true);
      setError('');
      await gameApi.deleteGame(gameId, characterId);
      if (gameId === currentGameId) {
        clearGameState();
      }
      await loadGames();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error al borrar la partida');
    } finally {
      setIsLoading(false);
    }
  };

  const startEditCharacter = async (gameId: string, characterId: number) => {
    setCurrentGameId(gameId);
    setCurrentCharacterId(characterId);
    chatIdRef.current = generateChatId();
    setMessages([{
      id: Date.now(),
      text: "¡Bienvenido a la edición de personaje! Solo podemos cambiar tu nombre ¿Te gustaría hacerlo?",
      type: 'system',
      timestamp: new Date().toLocaleTimeString()
    }]);
    setCurrentScreen('edit-character');
  };

  const sendMessage = async (message: string) => {
    if (!message.trim() || isLoading) return;

    try {
      setIsLoading(true);
      addMessage(message, 'dialog');

      let response;
      switch (currentScreen) {
        case 'create-character':
          response = await gameApi.sendCharacterAction(message, chatIdRef.current);
          break;
        case 'edit-character':
          response = await gameApi.sendEditAction(message, currentGameId, currentCharacterId, chatIdRef.current);
          break;
        case 'game':
          console.log('Enviando acción de juego:', { 
            message, 
            gameId: currentGameId, 
            characterId: currentCharacterId 
          });
          response = await gameApi.sendGameAction(message, currentGameId, currentCharacterId);
          break;
        default:
          throw new Error('Pantalla no válida para enviar mensajes');
      }

      handleServerResponse(response);
    } catch (error) {
      addMessage(
        `Error: ${error instanceof Error ? error.message : 'Error desconocido'}`,
        'system'
      );
    } finally {
      setIsLoading(false);
      setUserInput('');
    }
  };

  return {
    currentScreen,
    setCurrentScreen,
    games,
    messages,
    userInput,
    setUserInput,
    isLoading,
    error,
    currentGameId,
    currentCharacterId,
    startNewGame,
    loadGames,
    loadGame,
    deleteGame,
    startEditCharacter,
    sendMessage
  };
};
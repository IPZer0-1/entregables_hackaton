import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    // Ensure we're using HTTP for local development
    https: false,
    port: 5173
  }
});